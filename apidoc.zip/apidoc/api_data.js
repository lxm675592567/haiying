define({ "api": [
  {
    "type": "Post",
    "url": "/physical/heightAndWeight/findHeightAndWeightGraphData/{guid}",
    "title": "findHeightAndWeightGraphData",
    "group": "体格发育",
    "description": "<p>百分位统计表-根据guid获取体格发育数据曲线图(暂时不用)</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "guid",
            "description": "<p>档案号</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "传参示例",
          "content": "{\"guid\":\"EFIWFQE15PIH69NBYDFV3LPDTXTL5ES8\"}",
          "type": "String"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "src/main/java/haiying/service/physical/controller/HeightAndWeightController.java",
    "groupTitle": "体格发育",
    "name": "PostPhysicalHeightandweightFindheightandweightgraphdataGuid"
  },
  {
    "type": "Post",
    "url": "/physical/heightAndWeight/findHeightAndWeightHistoryPagination",
    "title": "findHeightAndWeightHistoryPagination",
    "group": "体格发育",
    "description": "<p>历史记录-根据传递的身高体重数据保存体格发育历史数据(暂未用到)</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Json",
            "optional": false,
            "field": "HeightAndWeight",
            "description": "<p>身高体重实体类</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "传参示例",
          "content": "{\"guid\":\"TQDV26PDGS15VAV58JA68OU5VX86GG81\",\"height\":100,\"weight\":43}",
          "type": "Json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "src/main/java/haiying/service/physical/controller/HeightAndWeightController.java",
    "groupTitle": "体格发育",
    "name": "PostPhysicalHeightandweightFindheightandweighthistorypagination"
  },
  {
    "type": "Post",
    "url": "/physical/heightAndWeight/getHeightAndWeightDateCurve",
    "title": "getHeightAndWeightDateCurve",
    "group": "体格发育",
    "description": "<p>获取曲线图数据</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "guid",
            "description": "<p>档案号</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "传参示例",
          "content": "{\"guid\":\"TQDV26PDGS15VAV58JA68OU5VX86GG81\"}",
          "type": "String"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "返回值示例",
          "content": "[\n    {\n        \"createTime\": \"2020-04-29 \",\n        \"weight\": 43.0,\n        \"height\": 100.0\n    },\n   {\n        \"createTime\": \"2020-04-30 \",\n        \"weight\": 44.0,\n        \"height\": 100.0\n    }\n]",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "src/main/java/haiying/service/physical/controller/HeightAndWeightController.java",
    "groupTitle": "体格发育",
    "name": "PostPhysicalHeightandweightGetheightandweightdatecurve"
  },
  {
    "type": "Post",
    "url": "/physical/heightAndWeight/saveOrEditHeightAndWeight",
    "title": "saveOrEditHeightAndWeight",
    "group": "体格发育",
    "description": "<p>保存-根据传递的身高体重数据保存体格发育数据</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Json",
            "optional": false,
            "field": "HeightAndWeight",
            "description": "<p>身高体重实体类</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "传参示例",
          "content": "{\"guid\":\"TQDV26PDGS15VAV58JA68OU5VX86GG81\",\"height\":100,\"weight\":43}",
          "type": "Json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "src/main/java/haiying/service/physical/controller/HeightAndWeightController.java",
    "groupTitle": "体格发育",
    "name": "PostPhysicalHeightandweightSaveoreditheightandweight"
  },
  {
    "type": "Post",
    "url": "/feed/findFeed",
    "title": "findFeed",
    "group": "喂养记录",
    "description": "<p>首页-喂养记录-统计 获取宝宝实时喂养记录信息</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "json",
            "optional": false,
            "field": "guid",
            "description": "<p>档案号</p>"
          },
          {
            "group": "Parameter",
            "type": "json",
            "optional": false,
            "field": "createTime",
            "description": "<p>查询的时间</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "传参示例",
          "content": "{\"guid\":\"EFIWFQE15PIH69NBYDFV3LPDTXTL5ES8\",\"createTime\":\"2020-04-23\"}",
          "type": "json"
        }
      ]
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "mrsecond",
            "description": "<p>母乳次数</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "mrTotal",
            "description": "<p>母乳分钟</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "pzmrsecond",
            "description": "<p>瓶装母乳次数</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "pzmrsuckle",
            "description": "<p>瓶装母乳含奶量</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "pfnsecond",
            "description": "<p>配方奶次数</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "pfnsuckle",
            "description": "<p>配方奶含奶量</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "fssecond",
            "description": "<p>辅食次数</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "nbsecond",
            "description": "<p>换尿布次数</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "smsecond",
            "description": "<p>睡眠次数</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "xxsecond",
            "description": "<p>嘘嘘次数</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "bbsecond",
            "description": "<p>便便次数</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "xbsecond",
            "description": "<p>嘘嘘+便便次数</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "spacing",
            "description": "<p>睡眠时间</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "返回值示例",
          "content": "{\"total\":[{\"id\":\"1254649324197404672\",\"guid\":\"EFIWFQE15PIH69NBYDFV3LPDTXTL5ES8\",\"typeName\":\"换尿布\",\"type\":\"5\",\"createTime\":\"2020-04-23 16:15:06\",\"endTime\":\"2020-04-23 16:17:05\",\"duration\":0,\"nurseContent\":0,\"selectType\":\"3\",\"selectTypeName\":\"xuxu+便便\",\"urineShape\":\"正常\",\"shitShape\":\"绿色\"},{\"id\":\"1255298935547256832\",\"guid\":\"EFIWFQE15PIH69NBYDFV3LPDTXTL5ES8\",\"typeName\":\"换尿布\",\"type\":\"5\",\"createTime\":\"2020-04-23 16:15:06\",\"endTime\":\"2020-04-23 16:27:05\",\"duration\":0,\"nurseContent\":0,\"selectType\":\"1\",\"selectTypeName\":\"xuxu\",\"urineShape\":\"正常\",\"shitShape\":\"绿色\"},{\"id\":\"1257965654136872960\",\"guid\":\"EFIWFQE15PIH69NBYDFV3LPDTXTL5ES8\",\"typeName\":\"换尿布\",\"type\":\"5\",\"createTime\":\"2020-04-23 16:15:06\",\"endTime\":\"2020-04-23 16:37:05\",\"duration\":0,\"nurseContent\":0,\"selectType\":\"2\",\"selectTypeName\":\"便便\",\"urineShape\":\"正常\",\"shitShape\":\"绿色\"},{\"id\":\"1254591084684140544\",\"guid\":\"EFIWFQE15PIH69NBYDFV3LPDTXTL5ES8\",\"typeName\":\"换尿布\",\"type\":\"5\",\"createTime\":\"2020-04-23 16:07:05\",\"endTime\":\"2020-04-23 16:47:05\",\"duration\":0,\"nurseContent\":0,\"selectType\":\"3\",\"selectTypeName\":\"xuxu+便便\",\"urineShape\":\"正常\",\"shitShape\":\"绿色\"},{\"id\":\"1254591268839251968\",\"guid\":\"EFIWFQE15PIH69NBYDFV3LPDTXTL5ES8\",\"typeName\":\"母乳亲喂\",\"type\":\"1\",\"lactation\":\"左侧哺乳\",\"createTime\":\"2020-04-23 16:06:08\",\"endTime\":\"2020-04-23 16:07:05\",\"duration\":2,\"nurseContent\":0},{\"id\":\"1254590934670663680\",\"guid\":\"EFIWFQE15PIH69NBYDFV3LPDTXTL5ES8\",\"typeName\":\"睡眠\",\"type\":\"6\",\"createTime\":\"2020-04-23 16:06:05\",\"endTime\":\"2020-04-23 16:35:05\",\"duration\":0,\"nurseContent\":0},{\"id\":\"1254642108090310656\",\"guid\":\"EFIWFQE15PIH69NBYDFV3LPDTXTL5ES8\",\"typeName\":\"母乳亲喂\",\"type\":\"1\",\"lactation\":\"左侧哺乳\",\"createTime\":\"2020-04-23 16:05:08\",\"endTime\":\"2020-04-23 16:07:05\",\"duration\":3,\"nurseContent\":0},{\"id\":\"1254591212543303680\",\"guid\":\"EFIWFQE15PIH69NBYDFV3LPDTXTL5ES8\",\"typeName\":\"配方奶\",\"type\":\"3\",\"createTime\":\"2020-04-23 16:05:06\",\"duration\":0,\"nurseContent\":120},{\"id\":\"1253607860331896832\",\"guid\":\"EFIWFQE15PIH69NBYDFV3LPDTXTL5ES8\",\"typeName\":\"瓶装母乳\",\"type\":\"2\",\"createTime\":\"2020-04-23 16:05:05\",\"duration\":0,\"nurseContent\":100}],\"census\":{\"xxsecond\":\"1\",\"pzmrsecond\":\"1\",\"pzmrsuckle\":\"100\",\"spacing\":\"1小时13分钟\",\"xbsecond\":\"2\",\"bbsecond\":\"1\",\"nbsecond\":\"4\",\"smsecond\":\"1\",\"mrsecond\":\"2\",\"pfnsuckle\":\"120\",\"mrTotal\":\"5\",\"pfnsecond\":\"1\"}}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "src/main/java/haiying/service/feed/controller/FeedController.java",
    "groupTitle": "喂养记录",
    "name": "PostFeedFindfeed"
  },
  {
    "type": "Post",
    "url": "/feed/getDateCurve",
    "title": "getDateCurve",
    "group": "喂养记录",
    "description": "<p>首页-喂养记录-统计(图标) 获取宝宝喂养记录曲线图</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "json",
            "optional": false,
            "field": "guid",
            "description": "<p>档案号</p>"
          },
          {
            "group": "Parameter",
            "type": "json",
            "optional": false,
            "field": "createTime",
            "description": "<p>查询的时间</p>"
          },
          {
            "group": "Parameter",
            "type": "json",
            "optional": false,
            "field": "feedtype",
            "description": "<p>喂奶:1 辅食:2 换尿布:3 睡眠:4</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "传参示例",
          "content": "{\"guid\":\"EFIWFQE15PIH69NBYDFV3LPDTXTL5ES8\",\"createTime\":\"2020-04\",\"feedtype\":\"1\"}",
          "type": "json"
        }
      ]
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "nurseTotal",
            "description": "<p>喂奶量</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "count",
            "description": "<p>次数</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "createTime",
            "description": "<p>时间</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "spacing",
            "description": "<p>睡眠时长</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "返回值示例",
          "content": "[\n    {\n        \"nurseTotal\": 220,\n        \"createTime\": \"2020-04-23 \",\n        \"count\": 4\n    },\n    {\n        \"nurseTotal\": 0,\n        \"createTime\": \"2020-04-24 \",\n        \"count\": 1\n    }\n]",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "src/main/java/haiying/service/feed/controller/FeedController.java",
    "groupTitle": "喂养记录",
    "name": "PostFeedGetdatecurve"
  },
  {
    "type": "Post",
    "url": "/feed/saveFeed",
    "title": "saveFeed",
    "group": "喂养记录",
    "description": "<p>保存宝宝实时喂养记录信息</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "json",
            "optional": false,
            "field": "feed",
            "description": "<p>喂养记录实体类</p>"
          },
          {
            "group": "Parameter",
            "type": "json",
            "optional": false,
            "field": "guid",
            "description": "<p>(必传) 档案号</p>"
          },
          {
            "group": "Parameter",
            "type": "json",
            "optional": false,
            "field": "type",
            "description": "<p>(必传) 类型  1母乳亲喂  2瓶装母乳  3配方奶  4辅食  5换尿布  6睡眠</p>"
          },
          {
            "group": "Parameter",
            "type": "json",
            "optional": false,
            "field": "typeName",
            "description": "<p>类型名称 母乳亲喂  瓶装母乳  配方奶  辅食  换尿布  睡眠</p>"
          },
          {
            "group": "Parameter",
            "type": "json",
            "optional": false,
            "field": "createTime",
            "description": "<p>开始时间</p>"
          },
          {
            "group": "Parameter",
            "type": "json",
            "optional": false,
            "field": "endTime",
            "description": "<p>结束时间</p>"
          },
          {
            "group": "Parameter",
            "type": "json",
            "optional": false,
            "field": "duration",
            "description": "<p>哺乳时长</p>"
          },
          {
            "group": "Parameter",
            "type": "json",
            "optional": false,
            "field": "nurseContent",
            "description": "<p>喂奶量</p>"
          },
          {
            "group": "Parameter",
            "type": "json",
            "optional": false,
            "field": "foodName",
            "description": "<p>辅食名称</p>"
          },
          {
            "group": "Parameter",
            "type": "json",
            "optional": false,
            "field": "foodDescribe",
            "description": "<p>辅食描述</p>"
          },
          {
            "group": "Parameter",
            "type": "json",
            "optional": false,
            "field": "foodPhoto",
            "description": "<p>辅食照片</p>"
          },
          {
            "group": "Parameter",
            "type": "json",
            "optional": false,
            "field": "selectType",
            "description": "<p>换尿布选择类型 1嘘嘘 2便便  3嘘嘘+便便</p>"
          },
          {
            "group": "Parameter",
            "type": "json",
            "optional": false,
            "field": "selectTypeName",
            "description": "<p>换尿布选择类型</p>"
          },
          {
            "group": "Parameter",
            "type": "json",
            "optional": false,
            "field": "urineShape",
            "description": "<p>嘘嘘形状</p>"
          },
          {
            "group": "Parameter",
            "type": "json",
            "optional": false,
            "field": "shitShape",
            "description": "<p>便便形状</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "传参示例",
          "content": "{\"guid\":\"EFIWFQE15PIH69NBYDFV3LPDTXTL5ES8\",\"type\":\"5\",\"typeName\":\"换尿布\",\"createTime\":\"2020-04-23 16:15:06\",\"selectTypeName\":\"xuxu+便便\",\"urineShape\":\"正常\",\"shitShape\":\"绿色\"}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "src/main/java/haiying/service/feed/controller/FeedController.java",
    "groupTitle": "喂养记录",
    "name": "PostFeedSavefeed"
  },
  {
    "type": "Post",
    "url": "/archives/record/getGrowUpArchives",
    "title": "getGrowUpArchives",
    "group": "成长档案",
    "description": "<p>成长档案-获取宝宝基本</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "json",
            "optional": false,
            "field": "jsonObject",
            "description": ""
          }
        ]
      },
      "examples": [
        {
          "title": "传参示例",
          "content": "{\"guid\":\"EFIWFQE15PIH69NBYDFV3LPDTXTL5ES8\",\"pageSize\":5,\"pageNum\":1}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "返回值示例",
          "content": "{\"feed\":[{\"id\":\"1254591150861869056\",\"guid\":\"EFIWFQE15PIH69NBYDFV3LPDTXTL5ES8\",\"typeName\":\"辅食\",\"type\":\"4\",\"createTime\":\"2020-04-24 16:05:15\",\"nurseContent\":0,\"foodName\":\"米粉\",\"foodDescribe\":\"少量\"},{\"id\":\"1254649324197404672\",\"guid\":\"EFIWFQE15PIH69NBYDFV3LPDTXTL5ES8\",\"typeName\":\"换尿布\",\"type\":\"5\",\"createTime\":\"2020-04-23 16:15:06\",\"nurseContent\":0,\"selectType\":\"3\",\"selectTypeName\":\"xuxu+便便\",\"urineShape\":\"正常\",\"shitShape\":\"绿色\"},{\"id\":\"1255298935547256832\",\"guid\":\"EFIWFQE15PIH69NBYDFV3LPDTXTL5ES8\",\"typeName\":\"换尿布\",\"type\":\"5\",\"createTime\":\"2020-04-23 16:15:06\",\"nurseContent\":0,\"selectTypeName\":\"xuxu+便便\",\"urineShape\":\"正常\",\"shitShape\":\"绿色\"},{\"id\":\"1254591084684140544\",\"guid\":\"EFIWFQE15PIH69NBYDFV3LPDTXTL5ES8\",\"typeName\":\"换尿布\",\"type\":\"5\",\"createTime\":\"2020-04-23 16:07:05\",\"nurseContent\":0,\"selectType\":\"3\",\"selectTypeName\":\"xuxu+便便\",\"urineShape\":\"正常\",\"shitShape\":\"绿色\"},{\"id\":\"1254591268839251968\",\"guid\":\"EFIWFQE15PIH69NBYDFV3LPDTXTL5ES8\",\"typeName\":\"母乳亲喂\",\"type\":\"1\",\"lactation\":\"左侧哺乳\",\"createTime\":\"2020-04-23 16:06:08\",\"endTime\":\"2020-04-23 16:07:05\",\"duration\":\"2\",\"nurseContent\":0}],\"heightAndWeight\":{\"weight\":33.0,\"bmi\":27.3,\"height\":110.0}}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "src/main/java/haiying/service/archives/controller/RecordController.java",
    "groupTitle": "成长档案",
    "name": "PostArchivesRecordGetgrowuparchives"
  },
  {
    "type": "Post",
    "url": "/archives/record/getBabyArchives",
    "title": "getBabyArchives",
    "group": "档案信息",
    "description": "<p>我的-已登入 获取所有宝宝基本信息</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "openId",
            "description": "<p>微信openId</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "传参示例",
          "content": "{\"guid\":\"TQDV26PDGS15VAV58JA68OU5VX86GG81\"}",
          "type": "String"
        }
      ]
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "record",
            "description": "<p>宝宝基础信息</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "返回值示例",
          "content": "[\n    {\n        \"record\": {\n            \"guid\": \"TQDV26PDGS15VAV58JA68OU5VX86GG81\",\n            \"cardId\": \"20190515000003\",\n            \"name\": \"刘静\",\n            \"sex\": \"女\",\n            \"birthday\": \"2019-04-17\",\n            \"ageDetail\": {\n                \"year\": 1,\n                \"month\": 0,\n                \"day\": 19,\n                \"monthAgeInt\": 12,\n                \"ageDetail\": \"1岁0月19天\",\n                \"monthAge\": 12.6\n            },\n            \"openId\": \"ojP-tvwqOu-kwE4qxKqhFJSC3KOw\"\n        },\n        \"name\": \"刘静\",\n        \"age\": \"1岁0月19天\"\n    }\n]",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "src/main/java/haiying/service/archives/controller/RecordController.java",
    "groupTitle": "档案信息",
    "name": "PostArchivesRecordGetbabyarchives"
  },
  {
    "type": "Post",
    "url": "/archives/record/saveRecord",
    "title": "saveRecord",
    "group": "档案信息",
    "description": "<p>我的-保存宝宝信息</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "json",
            "optional": false,
            "field": "record",
            "description": "<p>宝宝信息实体类</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "guid",
            "description": "<p>前端生成32位随机数</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "传参示例",
          "content": "{\"guid\":\"TQDV26PDGS15VAV58JA68OU5VX86GG83\",\"name\":\"李白\",\"sex\":\"1\",\"birthHeight\":\"20\",\"birthWeight\":\"10\",\"pregnancySecond\":\"1\",\"yieldSecond\":\"1\",\"url\":\"http://39.100.115.122:9000/bladex-chengde/upload/20200304/8ea6b9efc40f40f194c33a845f833dc3.jpg\"}",
          "type": "json"
        }
      ]
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "cardId",
            "description": "<p>卡号</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "name",
            "description": "<p>姓名</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "sex",
            "description": "<p>性别(0未知1男2女)</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "birthHeight",
            "description": "<p>出生身长</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "birthWeight",
            "description": "<p>出生体重</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "pregnancySecond",
            "description": "<p>第几孕</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "yieldSecond",
            "description": "<p>第几产</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "pregnantWeek",
            "description": "<p>出生孕周</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "返回值示例",
          "content": "{\n    \"status\": 0,\n    \"msg\": \"ok\",\n    \"result\": {\n        \"guid\": \"TQDV26PDGS15VAV58JA68OU5VX86GG83\",\n        \"cardId\": \"20200506000008\",\n        \"name\": \"李白\",\n        \"sex\": \"1\",\n        \"birthHeight\": \"20\",\n        \"birthWeight\": \"10\",\n        \"pregnancySecond\": \"1\",\n        \"yieldSecond\": \"1\"\n    },\n    \"success\": true\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "src/main/java/haiying/service/archives/controller/RecordController.java",
    "groupTitle": "档案信息",
    "name": "PostArchivesRecordSaverecord"
  },
  {
    "type": "Put",
    "url": "/archives/record/updateRecord",
    "title": "updateRecord",
    "group": "档案信息",
    "description": "<p>我的-修改宝宝信息</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "json",
            "optional": false,
            "field": "record",
            "description": "<p>宝宝信息实体类</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "传参示例",
          "content": "{\"guid\":\"TQDV26PDGS15VAV58JA68OU5VX86GG83\",\"name\":\"李白\",\"sex\":\"1\",\"birthHeight\":\"20\",\"birthWeight\":\"10\",\"pregnancySecond\":\"1\",\"yieldSecond\":\"1\",\"url\":\"http://39.100.115.122:9000/bladex-chengde/upload/20200304/8ea6b9efc40f40f194c33a845f833dc3.jpg\"}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "返回值示例",
          "content": "{\"status\":0,\"msg\":\"ok\",\"result\":{\"guid\":\"TQDV26PDGS15VAV58JA68OU5VX86GG83\",\"name\":\"李太白\",\"sex\":\"1\",\"birthHeight\":\"20\",\"birthWeight\":\"10\",\"pregnancySecond\":\"1\",\"yieldSecond\":\"1\"},\"success\":true}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "src/main/java/haiying/service/archives/controller/RecordController.java",
    "groupTitle": "档案信息",
    "name": "PutArchivesRecordUpdaterecord"
  },
  {
    "type": "Get",
    "url": "/user/auth",
    "title": "auth",
    "group": "用户权限",
    "description": "<p>通过code获取openid等基本信息</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>微信code</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "传参示例",
          "content": "{\n \"code\": \"EFIWFQE15PIH69NBYDFV3LPDTXTL5ES8\"\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "loginType",
            "description": "<p>登入状态(0注册1登入)</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "gender",
            "description": "<p>性别(0未知1男2女)</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "city",
            "description": "<p>城市</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "country",
            "description": "<p>国家</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "province",
            "description": "<p>省份</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "avatarUrl",
            "description": "<p>用户图片头像url</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "createTime",
            "description": "<p>创建时间</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "birthday",
            "description": "<p>出生日期</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "phone",
            "description": "<p>手机号</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "height",
            "description": "<p>身高</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "menstruation",
            "description": "<p>末次月经</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "返回值示例",
          "content": "{\"userId\":0,\"openId\":\"ojP-tvwqOu-kwE4qxKqhFJSC3KOw\",\"gender\":0,\"city\":0,\"loginType\":0}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "src/main/java/haiying/service/auth/controller/UserController.java",
    "groupTitle": "用户权限",
    "name": "GetUserAuth"
  },
  {
    "type": "Put",
    "url": "/user/updateUserInfo",
    "title": "updateUserInfo",
    "group": "用户权限",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Json",
            "optional": false,
            "field": "User",
            "description": "<p>用户信息</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "传参示例",
          "content": "{\"openId\":\"ojP-tvwqOu-kwE4qxKqhFJSC3KOw\",\"gender\":1,\"city\":\"济南\",\"nickName\":\"王维\",\"avatarUrl\":\"dasdsa\",\"country\":\"中国\",\"province\":\"山东省\"}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "返回值示例",
          "content": "{\"status\":0,\"msg\":\"ok\",\"result\":{\"openId\":\"ojP-tvwqOu-kwE4qxKqhFJSC3KOw\",\"gender\":1,\"country\":\"中国\",\"province\":\"山东省\",\"city\":\"济南\",\"avatarUrl\":\"dasdsa\",\"loginType\":0},\"success\":true}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "src/main/java/haiying/service/auth/controller/UserController.java",
    "groupTitle": "用户权限",
    "name": "PutUserUpdateuserinfo"
  },
  {
    "type": "Get",
    "url": "/archives/record/findOne/{openId}",
    "title": "findOne",
    "group": "首页",
    "description": "<p>首页通过guid获取宝宝档案信息 (头像,出生日期等)</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "guid",
            "description": "<p>档案号</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "返回值示例",
          "content": "{\n    \"guid\": \"TQDV26PDGS15VAV58JA68OU5VX86GG81\",\n    \"cardId\": \"20190515000003\",\n    \"name\": \"刘静\",\n    \"sex\": \"女\",\n    \"birthday\": \"2019-04-17\",\n    \"openId\": \"1\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "src/main/java/haiying/service/archives/controller/RecordController.java",
    "groupTitle": "首页",
    "name": "GetArchivesRecordFindoneOpenid"
  },
  {
    "type": "Post",
    "url": "/archives/record/findMessageOne",
    "title": "findMessageOne",
    "group": "首页",
    "description": "<p>首页通过openId获取宝宝信息</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "openId",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "guid",
            "description": "<p>(没有不传)</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "createTime",
            "description": "<p>时间</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "pageSize",
            "description": "<p>每页数</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "pageNum",
            "description": "<p>当前页</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "传参示例",
          "content": "{\"openId\":\"ojP-tvwqOu-kwE4qxKqhFJSC3KOw\",\"guid\":\"EFIWFQE15PIH69NBYDFV3LPDTXTL5ES8\",\"pageSize\":5,\"pageNum\":1,\"createTime\":\"2019-04-17\"}",
          "type": "json"
        }
      ]
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "record",
            "description": "<p>宝宝基础信息(同findone接口)</p>"
          },
          {
            "group": "Success 200",
            "type": "json",
            "optional": false,
            "field": "History",
            "description": "<p>宝宝历史喂养记录(同findFeedPagination接口)</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "返回值示例",
          "content": "{\n    \"record\": {\n        \"guid\": \"EFIWFQE15PIH69NBYDFV3LPDTXTL5ES8\",\n        \"cardId\": \"20190515000003\",\n        \"name\": \"刘静\",\n        \"sex\": \"女\",\n        \"birthday\": \"2019-04-17\",\n        \"openId\": \"ojP-tvwqOu-kwE4qxKqhFJSC3KOw\"\n    },\n    \"History\": [\n        {\n            \"id\": \"1254591150861869056\",\n            \"guid\": \"EFIWFQE15PIH69NBYDFV3LPDTXTL5ES8\",\n            \"typeName\": \"辅食\",\n            \"type\": \"4\",\n            \"createTime\": \"2020-04-24 16:05:15\",\n            \"duration\": 0,\n            \"nurseContent\": 0,\n            \"foodName\": \"米粉\",\n            \"foodDescribe\": \"少量\"\n        },\n        {\n            \"id\": \"1254649324197404672\",\n            \"guid\": \"EFIWFQE15PIH69NBYDFV3LPDTXTL5ES8\",\n            \"typeName\": \"换尿布\",\n            \"type\": \"5\",\n            \"createTime\": \"2020-04-23 16:15:06\",\n            \"endTime\": \"2020-04-23 16:17:05\",\n            \"duration\": 0,\n            \"nurseContent\": 0,\n            \"selectType\": \"3\",\n            \"selectTypeName\": \"xuxu+便便\",\n            \"urineShape\": \"正常\",\n            \"shitShape\": \"绿色\"\n        },\n        {\n            \"id\": \"1255298935547256832\",\n            \"guid\": \"EFIWFQE15PIH69NBYDFV3LPDTXTL5ES8\",\n            \"typeName\": \"换尿布\",\n            \"type\": \"5\",\n            \"createTime\": \"2020-04-23 16:15:06\",\n            \"endTime\": \"2020-04-23 16:27:05\",\n            \"duration\": 0,\n            \"nurseContent\": 0,\n            \"selectType\": \"1\",\n            \"selectTypeName\": \"xuxu\",\n            \"urineShape\": \"正常\",\n            \"shitShape\": \"绿色\"\n        },\n        {\n            \"id\": \"1257965654136872960\",\n            \"guid\": \"EFIWFQE15PIH69NBYDFV3LPDTXTL5ES8\",\n            \"typeName\": \"换尿布\",\n            \"type\": \"5\",\n            \"createTime\": \"2020-04-23 16:15:06\",\n            \"endTime\": \"2020-04-23 16:37:05\",\n            \"duration\": 0,\n            \"nurseContent\": 0,\n            \"selectType\": \"2\",\n            \"selectTypeName\": \"便便\",\n            \"urineShape\": \"正常\",\n            \"shitShape\": \"绿色\"\n        },\n        {\n            \"id\": \"1254591084684140544\",\n            \"guid\": \"EFIWFQE15PIH69NBYDFV3LPDTXTL5ES8\",\n            \"typeName\": \"换尿布\",\n            \"type\": \"5\",\n            \"createTime\": \"2020-04-23 16:07:05\",\n            \"endTime\": \"2020-04-23 16:47:05\",\n            \"duration\": 0,\n            \"nurseContent\": 0,\n            \"selectType\": \"3\",\n            \"selectTypeName\": \"xuxu+便便\",\n            \"urineShape\": \"正常\",\n            \"shitShape\": \"绿色\"\n        }\n    ]\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "src/main/java/haiying/service/archives/controller/RecordController.java",
    "groupTitle": "首页",
    "name": "PostArchivesRecordFindmessageone"
  },
  {
    "type": "Post",
    "url": "/feed/findFeedPagination",
    "title": "findFeedPagination",
    "group": "首页",
    "description": "<p>首页-动态 获取宝宝喂养记录动态历史</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "json",
            "optional": false,
            "field": "guid",
            "description": "<p>档案号   pageSize:每页固定数  pageNum:开始</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "传参示例",
          "content": "{\"guid\":\"EFIWFQE15PIH69NBYDFV3LPDTXTL5ES8\",\"pageSize\":5,\"pageNum\":1}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "返回值示例",
          "content": "[{\"id\":\"1254591150861869056\",\"guid\":\"EFIWFQE15PIH69NBYDFV3LPDTXTL5ES8\",\"typeName\":\"辅食\",\"type\":\"4\",\"createTime\":\"2020-04-24 16:05:15\",\"nurseContent\":0,\"foodName\":\"米粉\",\"foodDescribe\":\"少量\"},{\"id\":\"1254649324197404672\",\"guid\":\"EFIWFQE15PIH69NBYDFV3LPDTXTL5ES8\",\"typeName\":\"换尿布\",\"type\":\"5\",\"createTime\":\"2020-04-23 16:15:06\",\"nurseContent\":0,\"selectType\":\"3\",\"selectTypeName\":\"xuxu+便便\",\"urineShape\":\"正常\",\"shitShape\":\"绿色\"},{\"id\":\"1255298935547256832\",\"guid\":\"EFIWFQE15PIH69NBYDFV3LPDTXTL5ES8\",\"typeName\":\"换尿布\",\"type\":\"5\",\"createTime\":\"2020-04-23 16:15:06\",\"nurseContent\":0,\"selectTypeName\":\"xuxu+便便\",\"urineShape\":\"正常\",\"shitShape\":\"绿色\"},{\"id\":\"1254591084684140544\",\"guid\":\"EFIWFQE15PIH69NBYDFV3LPDTXTL5ES8\",\"typeName\":\"换尿布\",\"type\":\"5\",\"createTime\":\"2020-04-23 16:07:05\",\"nurseContent\":0,\"selectType\":\"3\",\"selectTypeName\":\"xuxu+便便\",\"urineShape\":\"正常\",\"shitShape\":\"绿色\"},{\"id\":\"1254591268839251968\",\"guid\":\"EFIWFQE15PIH69NBYDFV3LPDTXTL5ES8\",\"typeName\":\"母乳亲喂\",\"type\":\"1\",\"lactation\":\"左侧哺乳\",\"createTime\":\"2020-04-23 16:06:08\",\"endTime\":\"2020-04-23 16:07:05\",\"duration\":\"2\",\"nurseContent\":0}]",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "src/main/java/haiying/service/feed/controller/FeedController.java",
    "groupTitle": "首页",
    "name": "PostFeedFindfeedpagination"
  }
] });
