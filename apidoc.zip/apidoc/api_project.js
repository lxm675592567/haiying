define({
  "name": "haiying",
  "version": "0.0.0",
  "description": "通过小程序记录孩子的成长数据，配套智能家庭端设备--便携母乳分析仪，实时检测母乳质量，调整喂养方式。还能在线获取专业的指导方案，让自己的孩子更健康、更快乐地成长。",
  "title": "海婴母乳小程序",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2020-05-12T01:34:13.676Z",
    "url": "http://apidocjs.com",
    "version": "0.20.1"
  }
});
